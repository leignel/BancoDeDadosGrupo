--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ofertas_express1;
--
-- Name: ofertas_express1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ofertas_express1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE ofertas_express1 OWNER TO postgres;

\connect ofertas_express1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    cate_cd_id integer NOT NULL,
    cate_tx_nome character varying(30) NOT NULL,
    cate_tx_descricao character varying(200) NOT NULL
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: categoria_cate_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_cate_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categoria_cate_cd_id_seq OWNER TO postgres;

--
-- Name: categoria_cate_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_cate_cd_id_seq OWNED BY public.categoria.cate_cd_id;


--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto (
    prod_cd_id integer NOT NULL,
    prod_tx_nome character varying(30) NOT NULL,
    prod_tx_descricao character varying(200) NOT NULL,
    prod_int_qntestoque integer NOT NULL,
    prod_dt_datafabri date NOT NULL,
    prod_nm_valoruni numeric NOT NULL,
    fk_usuario_id integer,
    fk_cate_id integer
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: consultavaloreletronico; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.consultavaloreletronico AS
 SELECT p.prod_tx_nome AS produto,
    p.prod_nm_valoruni AS preco_unitario
   FROM (public.produto p
     JOIN public.categoria c ON ((p.fk_cate_id = c.cate_cd_id)))
  WHERE ((c.cate_tx_nome)::text = 'Eletrônicos'::text);


ALTER TABLE public.consultavaloreletronico OWNER TO postgres;

--
-- Name: contato; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contato (
    contato_cd_id integer NOT NULL,
    cont_tx_telfix character varying(15) NOT NULL,
    end_tx_celular character varying(16) NOT NULL,
    end_tx_email character varying(100) NOT NULL
);


ALTER TABLE public.contato OWNER TO postgres;

--
-- Name: contato_contato_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contato_contato_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contato_contato_cd_id_seq OWNER TO postgres;

--
-- Name: contato_contato_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contato_contato_cd_id_seq OWNED BY public.contato.contato_cd_id;


--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endereco (
    end_cd_id integer NOT NULL,
    end_tx_rua character varying(100) NOT NULL,
    end_int_num integer NOT NULL,
    end_tx_complemento character varying(20) NOT NULL,
    end_tx_bairro character varying(30) NOT NULL,
    end_tx_cidade character varying(30) NOT NULL,
    end_tx_estado character varying(30) NOT NULL,
    end_tx_cep character varying(9) NOT NULL
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endereco_end_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.endereco_end_cd_id_seq OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endereco_end_cd_id_seq OWNED BY public.endereco.end_cd_id;


--
-- Name: pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido (
    pedido_cd_id integer NOT NULL,
    pedido_dt_data date NOT NULL,
    fk_pedprod_cd_id integer,
    fk_usuario_cd_id integer
);


ALTER TABLE public.pedido OWNER TO postgres;

--
-- Name: pedidoproduto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedidoproduto (
    pedprod_cd_id integer NOT NULL,
    pedprod_dt_data date NOT NULL,
    pedprod_int_qnt integer NOT NULL,
    fk_prod_cd_id integer
);


ALTER TABLE public.pedidoproduto OWNER TO postgres;

--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    usuario_cd_id integer NOT NULL,
    usuario_tx_nome character varying(50) NOT NULL,
    usuario_tx_login character varying(50) NOT NULL,
    usuario_tx_cpf character varying(14) NOT NULL,
    usuario_tx_nascimento date NOT NULL,
    fk_end_cd_id integer,
    fk_contato_cd_id integer
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: nota_fiscal; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.nota_fiscal AS
 SELECT ped.pedido_cd_id AS numero_nota,
    ped.pedido_dt_data AS data_emissao,
    u.usuario_tx_nome AS nome_cliente,
    u.usuario_tx_cpf AS cpf_cliente,
    e.end_tx_rua AS endereco_entrega,
    e.end_int_num AS numero_entrega,
    e.end_tx_complemento AS complemento_entrega,
    e.end_tx_bairro AS bairro_entrega,
    e.end_tx_cidade AS cidade_entrega,
    e.end_tx_estado AS estado_entrega,
    e.end_tx_cep AS cep_entrega,
    p.prod_tx_nome AS nome_produto,
    pp.pedprod_int_qnt AS quantidade,
    p.prod_nm_valoruni AS valor_unitario,
    ((pp.pedprod_int_qnt)::numeric * p.prod_nm_valoruni) AS valor_total
   FROM ((((public.pedido ped
     JOIN public.usuario u ON ((ped.fk_usuario_cd_id = u.usuario_cd_id)))
     JOIN public.pedidoproduto pp ON ((ped.pedido_cd_id = pp.fk_prod_cd_id)))
     JOIN public.produto p ON ((pp.fk_prod_cd_id = p.prod_cd_id)))
     JOIN public.endereco e ON ((u.fk_end_cd_id = e.end_cd_id)));


ALTER TABLE public.nota_fiscal OWNER TO postgres;

--
-- Name: pedido_pedido_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_pedido_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_pedido_cd_id_seq OWNER TO postgres;

--
-- Name: pedido_pedido_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_pedido_cd_id_seq OWNED BY public.pedido.pedido_cd_id;


--
-- Name: pedidoproduto_pedprod_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedidoproduto_pedprod_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedidoproduto_pedprod_cd_id_seq OWNER TO postgres;

--
-- Name: pedidoproduto_pedprod_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedidoproduto_pedprod_cd_id_seq OWNED BY public.pedidoproduto.pedprod_cd_id;


--
-- Name: pedidosusuarios; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.pedidosusuarios AS
 SELECT u.usuario_tx_nome AS nome_usuario,
    ped.pedido_cd_id AS numero_pedido,
    pp.pedprod_dt_data AS data_pedido,
    pr.prod_tx_nome AS nome_produto,
    pp.pedprod_int_qnt AS quantidade
   FROM (((public.usuario u
     JOIN public.pedido ped ON ((u.usuario_cd_id = ped.fk_usuario_cd_id)))
     JOIN public.pedidoproduto pp ON ((ped.fk_pedprod_cd_id = pp.pedprod_cd_id)))
     JOIN public.produto pr ON ((pp.fk_prod_cd_id = pr.prod_cd_id)))
  WHERE ((u.usuario_tx_nome)::text = 'Rian'::text);


ALTER TABLE public.pedidosusuarios OWNER TO postgres;

--
-- Name: produto_prod_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_prod_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_prod_cd_id_seq OWNER TO postgres;

--
-- Name: produto_prod_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_prod_cd_id_seq OWNED BY public.produto.prod_cd_id;


--
-- Name: produtosdescricao; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.produtosdescricao AS
 SELECT produto.prod_tx_nome AS produto,
    produto.prod_tx_descricao AS "descrição"
   FROM public.produto;


ALTER TABLE public.produtosdescricao OWNER TO postgres;

--
-- Name: selecionaitensporcategoria; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.selecionaitensporcategoria AS
 SELECT c.cate_tx_nome AS categoria,
    count(p.prod_cd_id) AS total_de_produtos_por_categoria
   FROM (((public.categoria c
     JOIN public.produto p ON ((c.cate_cd_id = p.fk_cate_id)))
     JOIN public.pedidoproduto pp ON ((p.prod_cd_id = pp.fk_prod_cd_id)))
     JOIN public.pedido ped ON ((pp.fk_prod_cd_id = ped.fk_pedprod_cd_id)))
  GROUP BY c.cate_tx_nome;


ALTER TABLE public.selecionaitensporcategoria OWNER TO postgres;

--
-- Name: usuario_usuario_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_usuario_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_usuario_cd_id_seq OWNER TO postgres;

--
-- Name: usuario_usuario_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuario_usuario_cd_id_seq OWNED BY public.usuario.usuario_cd_id;


--
-- Name: usuariostelefone; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.usuariostelefone AS
 SELECT usuario.usuario_tx_nome AS nome_usuario,
    contato.cont_tx_telfix AS telefone
   FROM (public.usuario
     JOIN public.contato ON ((usuario.fk_contato_cd_id = contato.contato_cd_id)));


ALTER TABLE public.usuariostelefone OWNER TO postgres;

--
-- Name: categoria cate_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria ALTER COLUMN cate_cd_id SET DEFAULT nextval('public.categoria_cate_cd_id_seq'::regclass);


--
-- Name: contato contato_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contato ALTER COLUMN contato_cd_id SET DEFAULT nextval('public.contato_contato_cd_id_seq'::regclass);


--
-- Name: endereco end_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco ALTER COLUMN end_cd_id SET DEFAULT nextval('public.endereco_end_cd_id_seq'::regclass);


--
-- Name: pedido pedido_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido ALTER COLUMN pedido_cd_id SET DEFAULT nextval('public.pedido_pedido_cd_id_seq'::regclass);


--
-- Name: pedidoproduto pedprod_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedidoproduto ALTER COLUMN pedprod_cd_id SET DEFAULT nextval('public.pedidoproduto_pedprod_cd_id_seq'::regclass);


--
-- Name: produto prod_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN prod_cd_id SET DEFAULT nextval('public.produto_prod_cd_id_seq'::regclass);


--
-- Name: usuario usuario_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario ALTER COLUMN usuario_cd_id SET DEFAULT nextval('public.usuario_usuario_cd_id_seq'::regclass);


--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3413.dat

--
-- Data for Name: contato; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3411.dat

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3409.dat

--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3421.dat

--
-- Data for Name: pedidoproduto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3419.dat

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3417.dat

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3415.dat

--
-- Name: categoria_cate_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_cate_cd_id_seq', 5, true);


--
-- Name: contato_contato_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contato_contato_cd_id_seq', 5, true);


--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endereco_end_cd_id_seq', 5, true);


--
-- Name: pedido_pedido_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_pedido_cd_id_seq', 5, true);


--
-- Name: pedidoproduto_pedprod_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedidoproduto_pedprod_cd_id_seq', 5, true);


--
-- Name: produto_prod_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_prod_cd_id_seq', 5, true);


--
-- Name: usuario_usuario_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_usuario_cd_id_seq', 5, true);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (cate_cd_id);


--
-- Name: contato contato_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contato
    ADD CONSTRAINT contato_pkey PRIMARY KEY (contato_cd_id);


--
-- Name: endereco endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (end_cd_id);


--
-- Name: pedido pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (pedido_cd_id);


--
-- Name: pedidoproduto pedidoproduto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedidoproduto
    ADD CONSTRAINT pedidoproduto_pkey PRIMARY KEY (pedprod_cd_id);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (prod_cd_id);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (usuario_cd_id);


--
-- Name: idx_pedido_data; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pedido_data ON public.pedido USING btree (pedido_dt_data);


--
-- Name: idx_pedidoproduto_data; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pedidoproduto_data ON public.pedidoproduto USING btree (pedprod_dt_data);


--
-- Name: idx_pedidoproduto_produto; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pedidoproduto_produto ON public.pedidoproduto USING btree (fk_prod_cd_id);


--
-- Name: idx_produto_categoria; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_produto_categoria ON public.produto USING btree (fk_cate_id);


--
-- Name: idx_produto_datafabricacao; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_produto_datafabricacao ON public.produto USING btree (prod_dt_datafabri);


--
-- Name: pedido pedido_fk_pedprod_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_fk_pedprod_cd_id_fkey FOREIGN KEY (fk_pedprod_cd_id) REFERENCES public.pedidoproduto(pedprod_cd_id);


--
-- Name: pedido pedido_fk_usuario_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_fk_usuario_cd_id_fkey FOREIGN KEY (fk_usuario_cd_id) REFERENCES public.usuario(usuario_cd_id);


--
-- Name: pedidoproduto pedidoproduto_fk_prod_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedidoproduto
    ADD CONSTRAINT pedidoproduto_fk_prod_cd_id_fkey FOREIGN KEY (fk_prod_cd_id) REFERENCES public.produto(prod_cd_id);


--
-- Name: produto produto_fk_cate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_fk_cate_id_fkey FOREIGN KEY (fk_cate_id) REFERENCES public.categoria(cate_cd_id);


--
-- Name: produto produto_fk_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_fk_usuario_id_fkey FOREIGN KEY (fk_usuario_id) REFERENCES public.usuario(usuario_cd_id);


--
-- Name: usuario usuario_fk_contato_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_fk_contato_cd_id_fkey FOREIGN KEY (fk_contato_cd_id) REFERENCES public.contato(contato_cd_id);


--
-- Name: usuario usuario_fk_end_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_fk_end_cd_id_fkey FOREIGN KEY (fk_end_cd_id) REFERENCES public.endereco(end_cd_id);


--
-- PostgreSQL database dump complete
--

